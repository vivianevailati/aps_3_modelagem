# APS 3 — Dossiê de Arquitetura Viva
## Assistente de IA para Exportação — Sistema Fiep

**Unidade Curricular:** Modelagem de Software  
**Curso:** Engenharia de Software — 4º Período  
**Docente:** Prof. Sidney L. da Silva  
**Funcionalidade:** Coleta de dados da operação e gerenciamento de contexto  
**Requisitos:** RF02 e RF03

> **Autoria individual:** preencher os dados de identificação e realizar commits incrementais próprios no repositório.

---

## 1. Contextualização da funcionalidade

O Assistente de IA para Exportação tem como objetivo apoiar pequenas indústrias na compreensão de regras, documentos e procedimentos necessários à exportação. A solução recebe perguntas em linguagem natural e utiliza o contexto da operação para fornecer orientações mais adequadas.

Este dossiê detalha a funcionalidade de **Coleta de Dados da Operação e Gerenciamento de Contexto**, responsável por manter as informações já fornecidas pelo usuário e identificar quais dados ainda precisam ser coletados antes de encaminhar uma consulta ao pipeline RAG.

### 1.1 Requisitos funcionais relacionados

- **RF02 — Contexto da conversa (Crítico):** mantém o histórico da sessão atual e permite perguntas complementares sem que o usuário repita produto, NCM, destino e demais dados já informados.
- **RF03 — Coleta de dados da operação (Crítico):** quando a pergunta não contém os dados mínimos, o assistente solicita apenas as informações ausentes.

### 1.2 Dados considerados na coleta

O contexto da operação pode conter produto, NCM, país de origem, país de destino, quantidade e finalidade. A necessidade de cada campo deve respeitar o cenário da consulta. O sistema não deve inventar ou presumir dados ausentes; quando houver ambiguidade, deve solicitar confirmação.

### 1.3 Fluxo resumido

1. O usuário envia uma pergunta.
2. A API identifica a sessão e recupera seu contexto.
3. O serviço de linguagem natural extrai informações da mensagem.
4. O coletor mescla as informações novas com as já armazenadas.
5. O sistema verifica os campos mínimos.
6. Se houver pendências, solicita somente os campos ausentes e atualiza o contexto.
7. Se os dados estiverem completos, persiste o contexto e publica um evento para o pipeline RAG.

---

## 2. Artefato 1 — Diagrama de Sequência (UML / DaC)

Arquivo-fonte: `docs/diagrams/sequencia.mmd`

O diagrama representa a ordem das mensagens trocadas durante uma interação. As setas síncronas representam chamadas que aguardam retorno. As setas tracejadas representam respostas e retornos de dados. As setas assíncronas representam a publicação e o consumo do evento de contexto pronto.

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant API as API de Conversas
    participant Contexto as Servico de Contexto
    participant Repo as Repositorio de Contexto
    participant NLP as Extrator de Dados NLP
    participant Coletor as Coletor da Operacao
    participant Evento as Barramento de Eventos
    participant RAG as Orquestrador RAG

    Usuario->>API: enviarMensagem(MensagemDTO)
    API->>Contexto: recuperarContexto(SessaoDTO)
    Contexto->>Repo: buscarPorSessao(idSessao)
    Repo-->>Contexto: ContextoDTO ou null
    Contexto-->>API: ContextoDTO

    API->>NLP: extrairInformacoes(texto, ContextoDTO)
    NLP-->>API: ExtracaoDTO(produto, NCM, origem, destino, quantidade, finalidade)

    API->>Coletor: consolidarDados(ContextoDTO, ExtracaoDTO)
    Coletor->>Coletor: identificarCamposPendentes(ContextoDTO)

    alt Existem campos obrigatorios pendentes
        Coletor-->>API: ColetaDTO(status=PENDENTE, camposFaltantes)
        API->>Contexto: atualizarContexto(ContextoAtualizacaoDTO)
        Contexto->>Repo: salvar(ContextoDTO)
        Repo-->>Contexto: ContextoDTO atualizado
        Contexto-->>API: ContextoDTO atualizado
        API-->>Usuario: solicitarDadosPendentes(PerguntaDTO)
    else Dados minimos preenchidos
        Coletor-->>API: ColetaDTO(status=COMPLETO, operacaoDTO)
        API->>Contexto: atualizarContexto(ContextoAtualizacaoDTO)
        Contexto->>Repo: salvar(ContextoDTO)
        Repo-->>Contexto: ContextoDTO atualizado
        Contexto-->>API: ContextoDTO atualizado
        API-)Evento: publicarContextoPronto(ContextoProntoDTO)
        Evento-)RAG: consumirContextoPronto(ContextoProntoDTO)
        API-->>Usuario: apresentarStatusColeta(ConfirmacaoDTO)
    end
```

### DTOs utilizados

| DTO | Finalidade |
|---|---|
| `MensagemDTO` | Texto enviado pelo usuário e identificador da sessão. |
| `SessaoDTO` | Identifica a sessão cuja conversa será recuperada. |
| `ContextoDTO` | Histórico e dados já conhecidos da operação. |
| `ExtracaoDTO` | Informações identificadas na mensagem pelo NLP. |
| `ColetaDTO` | Resultado da validação: pendente ou completo. |
| `ContextoAtualizacaoDTO` | Dados novos que serão incorporados ao contexto. |
| `PerguntaDTO` | Pergunta contendo somente os campos pendentes. |
| `ContextoProntoDTO` | Evento assíncrono com referência ao contexto consolidado. |
| `OrientacaoInicialDTO` | Retorno inicial do processamento RAG. |

### Contrato de operações públicas

As mensagens do diagrama correspondem às operações públicas das respectivas linhas de vida:

| Participante | Operações públicas representadas |
|---|---|
| API de Conversas | `enviarMensagem(MensagemDTO)`, `solicitarDadosPendentes(PerguntaDTO)`, `apresentarConfirmacao(OrientacaoInicialDTO)` |
| Serviço de Contexto | `recuperarContexto(SessaoDTO)`, `atualizarContexto(ContextoAtualizacaoDTO)` |
| Repositório de Contexto | `buscarPorSessao(idSessao)`, `salvar(ContextoDTO)` |
| Extrator NLP | `extrairInformacoes(texto, ContextoDTO)` |
| Coletor da Operação | `consolidarDados(ContextoDTO, ExtracaoDTO)`, `identificarCamposPendentes(ContextoDTO)` |
| Barramento de Eventos | `publicarContextoPronto(ContextoProntoDTO)` |
| Orquestrador RAG | `consumirContextoPronto(ContextoProntoDTO)` |

---

## 3. Artefato 2 — Diagrama de Atividades com Raias (UML / DaC)

Arquivo-fonte: `docs/diagrams/atividades.mmd`

O diagrama está dividido em três raias: usuário/exportador, back-end/gerenciamento de contexto e serviços/infraestrutura. O nó de decisão separa os caminhos de dados incompletos e completos. A divisão e a sincronização representam tarefas paralelas após a publicação do contexto pronto.

```mermaid
flowchart TB
    %% Raias representam os responsáveis pelo workflow.
    subgraph R1["RAIA 1 — USUÁRIO / EXPORTADOR"]
        A([Início])
        B["Enviar pergunta em linguagem natural"]
        C["Responder à solicitação de dados pendentes"]
    end

    subgraph R2["RAIA 2 — BACK-END / GERENCIAMENTO DE CONTEXTO"]
        D["Receber mensagem e identificar sessão"]
        E["Recuperar ContextoDTO da sessão"]
        F["Extrair informações da mensagem"]
        G["Mesclar dados novos com contexto existente"]
        H{"Todos os campos mínimos estão preenchidos?"}
        I["Identificar somente os campos ausentes"]
        J1["Atualizar contexto com dados parciais"]
        J2["Atualizar contexto completo e marcar como PRONTO"]
        L["Publicar evento ContextoProntoDTO"]
    end

    subgraph R3["RAIA 3 — SERVIÇOS / INFRAESTRUTURA"]
        M["Consultar repositório de contexto"]
        N["Validar consistência dos dados da operação"]
        O1["Persistir contexto parcial"]
        O2["Persistir contexto completo"]
        P["Preparar contexto para o pipeline RAG"]
        T1["Registrar evento de auditoria"]
        T2["Preparar pacote de contexto"]
    end

    A --> B --> D --> E --> M --> F
    F --> G --> N --> H

    H -- "[não: existem campos ausentes]" --> I
    I --> J1 --> O1 --> C
    C --> D

    H -- "[sim: dados mínimos completos]" --> J2
    J2 --> O2 --> L
    L --> FORK{{"FORK — DIVISÃO"}}
    FORK --> T1
    FORK --> T2
    T1 --> JOIN{{"JOIN — SINCRONIZAÇÃO"}}
    T2 --> JOIN
    JOIN --> P --> FIM([Contexto disponível para o RAG])
```

### Interpretação

Quando os dados estão incompletos, o sistema identifica os campos ausentes, persiste o contexto atualizado e solicita complementação ao usuário. Quando os dados mínimos estão completos, o contexto é marcado como pronto e encaminhado ao pipeline RAG.

O fork permite registrar o evento de auditoria e preparar o pacote de contexto em paralelo. O join sincroniza as duas tarefas antes de disponibilizar o contexto para a próxima etapa.

---

## 4. Artefato 3 — Diagrama de Transição de Estados (State Machine / DaC)

Arquivo-fonte: `docs/diagrams/estados.mmd`

A entidade central é o **Contexto da Conversa**, que controla o ciclo de vida da coleta de informações da operação.

```mermaid
stateDiagram-v2
    [*] --> Contexto

    state "Contexto da Conversa" as Contexto {
        [*] --> Novo
        Novo --> Coletando: iniciarSessao() [sessaoValida] / criarContexto()
        Coletando --> Coletando: receberMensagem() [dadosParciais] / mesclarDados()
        Coletando --> Pronto: validarDados() [camposMinimosPreenchidos] / marcarComoPronto()
        Pronto --> Processando: iniciarConsultaRAG() [contextoConsistente] / publicarContexto()
        Processando --> Pronto: respostaConcluida() [sessaoAtiva] / registrarInteracao()
        Processando --> Coletando: solicitarComplemento() [informacaoInsuficiente] / registrarPendencias()
        Pronto --> Coletando: novaPergunta() [novosDadosNecessarios] / reabrirColeta()
        Coletando --> Expirado: expirarSessao() [tempoLimiteAtingido] / encerrarSessao()
        Pronto --> Expirado: expirarSessao() [tempoLimiteAtingido] / encerrarSessao()
        Processando --> Expirado: expirarSessao() [tempoLimiteAtingido] / cancelarProcessamento()

        state Coletando {
            [*] --> AguardandoDados
            AguardandoDados: entry / exibirCamposPendentes()
            AguardandoDados: do / aguardarRespostaUsuario()
            AguardandoDados: exit / validarNovosDados()
        }
    }

    Expirado --> [*]
```

### Descrição dos estados

| Estado | Significado |
|---|---|
| Novo | A sessão foi criada, mas ainda não possui dados suficientes. |
| Coletando | O sistema está recebendo, extraindo e complementando informações. |
| Pronto | Os dados mínimos foram preenchidos e validados. |
| Processando | O contexto foi encaminhado ao pipeline RAG. |
| Expirado | A sessão atingiu o tempo limite e foi encerrada. |

As guardas impedem que um contexto incompleto seja enviado para processamento. O estado `Expirado` é terminal. O estado `Coletando` possui ações internas de entrada, execução e saída.

---

## 5. Artefato 4 — Visão Arquitetural Macro C4 (Nível 2)

Arquivo-fonte: `docs/architecture/workspace.dsl`

A visão de contêineres apresenta as unidades executáveis e os armazenamentos que participam da funcionalidade. A arquitetura proposta utiliza React/TypeScript na interface, Node.js/TypeScript nos serviços de conversação e contexto, PostgreSQL 16 para persistência, RabbitMQ para eventos assíncronos e Python/FastAPI na orquestração RAG.

```structurizr
workspace "Assistente de IA para Exportação — Contexto e Coleta" "Visão C4 nível 2 da funcionalidade RF02 e RF03." {
    model {
        usuario = person "Usuário exportador" "Pessoa que consulta o assistente para obter orientações sobre uma operação de exportação."

        sistema = softwareSystem "Assistente de IA para Exportação" "Assistente que interpreta perguntas e fornece orientações de exportação fundamentadas." {
            frontend = container "Interface de Conversação" "Recebe mensagens e apresenta perguntas complementares e respostas." "React / TypeScript" 
            api = container "API de Conversas" "Recebe mensagens, identifica sessões e coordena os serviços de contexto e coleta." "Node.js / TypeScript / REST"
            contexto = container "Serviço de Contexto e Coleta" "Recupera o histórico, mescla informações da operação e identifica campos pendentes (RF02/RF03)." "Node.js / TypeScript"
            banco = container "Banco de Contextos" "Armazena sessões, mensagens e dados parciais ou completos das operações." "PostgreSQL 16"
            fila = container "Barramento de Eventos" "Distribui eventos assíncronos quando o contexto está pronto para processamento." "RabbitMQ"
            rag = container "Orquestrador RAG" "Recebe o contexto consolidado, consulta a base vetorial e solicita geração da resposta ao LLM." "Python / FastAPI"
            vetor = container "Base de Conhecimento Vetorial" "Armazena documentos e trechos regulatórios indexados para recuperação semântica." "PostgreSQL 16 / pgvector"
            llm = container "Serviço de Modelo de Linguagem" "Gera respostas em linguagem natural com base no contexto recuperado." "LLM via API"
        }

        usuario -> frontend "Envia perguntas e responde às solicitações de dados" "HTTPS"
        frontend -> api "Envia mensagens e recebe DTOs de resposta" "HTTPS / JSON / REST"
        api -> contexto "Recupera e atualiza o contexto da sessão" "REST / JSON"
        contexto -> banco "Consulta e persiste contexto e histórico" "SQL / TCP"
        api -> fila "Publica ContextoProntoDTO" "AMQP"
        fila -> rag "Entrega evento de contexto pronto" "AMQP"
        rag -> vetor "Busca trechos regulatórios relevantes" "SQL / pgvector"
        rag -> llm "Envia prompt contextualizado e recebe geração" "HTTPS / API"
        api -> frontend "Retorna pergunta complementar ou confirmação" "HTTPS / JSON"
    }

    views {
        container sistema {
            include *
            autolayout lr
        }
        styles {
            element "Person" {
                shape person
                background "#08427b"
                color "#ffffff"
            }
            element "Software System" {
                background "#1168bd"
                color "#ffffff"
            }
            element "Container" {
                background "#438dd5"
                color "#ffffff"
            }
        }
    }
}
```

### Justificativa da arquitetura

A separação entre API, serviço de contexto e orquestrador RAG reduz o acoplamento entre a coleta de dados e a geração de respostas. O PostgreSQL mantém o histórico e os dados estruturados da operação. O RabbitMQ permite encaminhar o contexto consolidado de forma assíncrona, sem manter a requisição do usuário bloqueada durante todo o processamento RAG.

As tecnologias representam uma proposta arquitetural para o dossiê e devem ser compatibilizadas com as decisões efetivamente adotadas pela equipe.

---

## 6. Artefato 5 — Registro de Decisão Arquitetural (ADR 0001)

Arquivo-fonte: `docs/architecture/adr-0001.md`

**ADR 0001 — Persistência incremental do contexto da operação**

**Status:** Aprovado

### Contexto

O assistente precisa manter informações fornecidas em mensagens diferentes e solicitar somente os dados ainda ausentes. Tratar cada pergunta isoladamente provocaria repetição de perguntas e perda de informações importantes para a análise de exportação.

### Decisão

Adotar um serviço de gerenciamento de contexto com persistência incremental em PostgreSQL 16 e coleta por campos (slot filling). A cada mensagem, o sistema recupera o contexto da sessão, extrai novos dados, mescla as informações, identifica campos pendentes e persiste a atualização. Quando os dados mínimos estiverem completos, publica o evento `ContextoProntoDTO` para o pipeline RAG.

### Consequências

**Vantagens:** continuidade da conversa, menor repetição de perguntas, coleta gradual, rastreabilidade, recuperação do contexto e desacoplamento do pipeline RAG.

**Custos e riscos:** necessidade de proteger dados por sessão, controlar retenção e expiração, tratar atualizações concorrentes, validar extrações feitas por IA e garantir idempotência no consumo dos eventos.

Consulte o registro completo em `docs/architecture/adr-0001.md`.

---

## 7. Consistência entre os artefatos

A coerência entre os cinco artefatos é garantida pelas seguintes relações:

1. **Sequência e atividades:** ambas representam recuperação do contexto, extração de dados, identificação de pendências, persistência e encaminhamento do contexto completo.
2. **Sequência e estados:** a coleta mantém o contexto em `Coletando`; o preenchimento dos campos permite a transição para `Pronto`; o evento encaminha o contexto para `Processando`.
3. **Atividades e estados:** a decisão sobre campos mínimos define se o fluxo permanece em coleta ou se libera o processamento.
4. **C4 e sequência:** os participantes da sequência são implementados pelos contêineres de API, serviço de contexto, PostgreSQL, RabbitMQ e orquestrador RAG.
5. **ADR e arquitetura:** a decisão de persistência incremental justifica o PostgreSQL e a separação do serviço de contexto.

---

## 8. Estrutura do repositório

```text
aps3-nome-sobrenome/
├── docs/
│   ├── architecture/
│   │   ├── workspace.dsl
│   │   └── adr-0001.md
│   └── diagrams/
│       ├── sequencia.mmd
│       ├── atividades.mmd
│       └── estados.mmd
└── README.md
```

---

## 9. Como validar e entregar

1. Criar um repositório público no GitHub com o nome `aps3-nome-sobrenome`.
2. Inserir os arquivos respeitando a estrutura indicada.
3. Conferir os diagramas Mermaid no preview do GitHub ou no Mermaid Live Editor.
4. Validar o `workspace.dsl` em uma ferramenta compatível com Structurizr DSL.
5. Conferir se os diagramas renderizam e se as mensagens e estados estão consistentes.
6. Realizar commits incrementais, registrando a evolução real do trabalho.
7. Inserir no AVA o link do repositório público.

### Sugestão de commits

- `docs: adiciona descrição da funcionalidade RF02 e RF03`
- `feat: cria diagrama de sequência do gerenciamento de contexto`
- `feat: modela atividades de coleta de dados`
- `feat: modela máquina de estados do contexto`
- `docs: adiciona arquitetura C4 e ADR 0001`
- `docs: consolida dossiê no README`

**Importante:** personalize o nome do repositório, revise as tecnologias com sua equipe e faça os commits durante a construção. A atividade é individual e a evolução do versionamento faz parte da auditoria.
